function mm = mockmean(a,b,c) 
mm = mean([a,b,c]); 
end 

