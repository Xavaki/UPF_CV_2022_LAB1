function imh = half_image( I )

% halves the image size as described by Lowe
imh=I(1:2:end,1:2:end) ;

end

